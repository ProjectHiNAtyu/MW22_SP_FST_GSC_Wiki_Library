# MW22_SP_FST_GSC_Wiki_Library

[ About ]

The GSCBIN Dump, GSC Injector, and GSC Dumper are based on the GSC Injection process devised by Mr. Sku-111 in Project Donetsk, which we have reconstructed and utilized.
I express my heartfelt respect and gratitude to Mr. Sku-111, who devised and implemented this injection process.
Additionally, the GSC Source is based on Mr. xensik's gsc-tool and has been decompiled.
Thank you always, and I support you.

----------

[ Support environment ]

Platform : PC ( Windows 10 , Windows 11 )
Game title : Call of Duty Modern Warfare II
Game release year : 2022
Support mode : SP ( Singleplayer *Campaign )
dll name : mw22_sp_injector.dll
Directory name : C:\Users\??\Documents\MW22_SP_FST_GSC_CUSTOM

----------

[ Video ]

If you’d like to learn more about this GSC Mod Menu, please check out the YouTube video below.
https://youtu.be/lhl8Dju5In8?si=6fNxM0s0E8H7AtKD

----------

[ Implemented ]

The following items are currently completed:

- dll Injector
- GSC Injector
- GSC Dumper
- GSCBIN Dump Data
- GSC Mod Menu - Project HiNAtyu ( Compiled )
- GSC Mod Menu - Project HiNAtyu ( Sourcecode )

----------

[ Caution ]

< Generic >

* This Injector was created for research, development, and educational purposes.
* This Injector was created for free release purposes.
* Unless there are significant bugs, I will not make fixes to the Injector.
* I recommend using it only with the MWII SP Offline build.
* It is not intended for use with any other games.
* Any use for unintended purposes is always at your own risk.
* If OneDrive is enabled, the software may not function properly, so please disable OneDrive if any issues occur.

* After using this Injector, be sure to restart your PC before playing other games.
* Shutting down or unplugging the power will not initialize the driver, which increases the risk of a BAN.
* Any BAN measures resulting from the use of this Injector are entirely at your own risk.

* To use this Face Injector on Windows 11, please use <MRON AIO FIXES.bat> distributed by MRON to fix your system.

* The driver for this Face Injector will be detected by the Retail Version of Call of Duty Ricochet.
* Be sure to use this Injector only with an offline version of MWII SP!
* If you use it with the Retail Version, the consequences are at your own risk.

----------

< GSC Injector / dll Injector ( Face injector ) >

Place this "MW22_SP_FST_GSC_CUSTOM" folder in the Documents folder on your PC.
Then, run "CoDMW22_SP_dll_Injector.exe" as an administrator.

Since this Face Injector operates at the kernel level, it may be flagged as a virus. Before running the app, disable the Windows antivirus system in advance.
After launching the app, once the driver is initialized, start Call of Duty Modern Warfare II Campaign Offline Build.
Once the game is launched, the Face Injector will recognize MWII SP and automatically begin the GSC Injection process.

Note that this Face Injector uses a driver pattern that is detected in the retail version of Call of Duty.
After using GSC in the MWII SP, if you plan to launch other games, restart your PC beforehand.
Shutting down the PC or unplugging the power cord will prevent the driver from initializing properly, increasing the risk of a ban.

Be sure to carefully restart your PC to avoid this.

----------

< gsc-tool >

This app is a command-line tool operated via cmd.
HiNAtyu does not accept questions regarding the tool.
Please direct your questions to xensik.
Please download and use the latest version of the release file for gsc-tool from xensik's official repository.

https://github.com/xensik/gsc-tool

----------

[ How to use ]

01. Install the CoD MWII Campaign offline build by h00dbyair on your PC and get it ready to launch the game.  
02. Download the file from this GitHub release page and extract the .zip archive.  
03. Place the "MW22_SP_FST_GSC_CUSTOM" folder, which is included in the extracted files, directly into your Documents folder.  
04. Disable your antivirus system.  
05. Run "CoDMW22_SP_dll_Injector.exe" with administrator privileges.  
06. Once the driver initialization is complete, launch CoD MWII SP.  
07. When the game starts, the display on the DLL Injector screen will change. If it shows that the injection was successful, wait as is.  
08. Please start your favorite mission.   
09. After the game starts, confirm that "Project HiNAtyu" is displayed on the screen.  
10. After you’re done playing with the Mod Menu, be sure to restart your PC before playing any other games.

----------

[ Custom GSC ( gsc-tool ) ]

< dump >
* A "GSCBIN" folder containing the gscbin for iw9 needs to be placed in the same directory hierarchy as gsc-tool.exe.
gsc-tool -m decomp -g iw9 -s pc GSCBIN

< compile >
* A "GSCModSource" folder containing the custom GSC source for iw9 needs to be placed in the same directory hierarchy as gsc-tool.exe.
gsc-tool -m comp -g iw9 -s pc GSCModSource

You are free to modify the GSC Mod Menu source code I released.
However, I will not provide explanations on how to modify GSC, coding methods, or basic coding knowledge.
Please figure it out on your own.

----------

[ Promotion ]

Discord : hinatapoko
Twitter 1 (Main) : https://x.com/KonataGIF
Twitter 2 (Sub) : https://x.com/H1NAtyu
YouTube : HiNAtyu Studio ( https://www.youtube.com/@hinatyuproject/featured )

I’d be very happy if you could follow, subscribe, like, or comment on my various SNS accounts. 
If you like my work, I'd be happy if you could sponsor or donate.
This will help facilitate the development of new features and fixes.

Ko-fi : https://ko-fi.com/hinatyustudio
BTC : 32J66dfWi9dqqWHS2RYR9rFCUNBL88vgUR
ETH : 0xaE5D5b3e8E865B2bA676a24eF41d5f4CBD315978
